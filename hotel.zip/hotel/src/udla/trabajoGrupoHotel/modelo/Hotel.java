package udla.trabajoGrupoHotel.modelo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Hotel {
    private String nombre;
    private String direccion;
    private List<Habitacion> habitaciones;

    public Hotel() {
        this.habitaciones = new ArrayList<>();
    }

    public Hotel(String nombre, String direccion) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.habitaciones = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public List<Habitacion> getHabitaciones() {
        return habitaciones;
    }

    public void agregarHabitacion(Habitacion habitacion) {
        habitaciones.add(habitacion);
    }

    public List<Habitacion> consultarDisponibilidad(Date fechaInicio, Date fechaFin) {
        List<Habitacion> habitacionesDisponibles = new ArrayList<>();
        for (Habitacion habitacion : habitaciones) {
            if (habitacion.esDisponible(fechaInicio, fechaFin)) {
                habitacionesDisponibles.add(habitacion);
            }
        }
        return habitacionesDisponibles;
    }

    public boolean realizarReserva(Reserva reserva) {
        if (reserva.getHabitacion().esDisponible(reserva.getFechaInicio(), reserva.getFechaFin())) {
            reserva.getHabitacion().getReservas().add(reserva);
            return true;
        }
        return false;
    }
}
