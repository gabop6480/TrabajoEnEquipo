package udla.trabajoGrupoHotel.modelo;

import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Reserva {
    private int numeroReserva;
    private Date fechaInicio;
    private Date fechaFin;
    private String cliente;
    private Habitacion habitacion;

    public Reserva(int numeroReserva, Date fechaInicio, Date fechaFin, String cliente, Habitacion habitacion) {
        this.numeroReserva = numeroReserva;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.cliente = cliente;
        this.habitacion = habitacion;
    }

    public int getNumeroReserva() {
        return numeroReserva;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public String getCliente() {
        return cliente;
    }

    public Habitacion getHabitacion() {
        return habitacion;
    }

    public long calcularDiasEstancia() {
        long diffInMillies = Math.abs(fechaFin.getTime() - fechaInicio.getTime());
        return TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
    }

    public double calcularCostoTotal() {
        return calcularDiasEstancia() * habitacion.getPrecioPorNoche();
    }
}





