package udla.trabajoGrupoHotel.modelo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Habitacion {
    private int numero;
    private String tipo;
    private double precioPorNoche;
    private List<Reserva> reservas;

    public Habitacion() {
        this.reservas = new ArrayList<>();
    }

    public Habitacion(int numero, String tipo, double precioPorNoche) {
        this.numero = numero;
        this.tipo = tipo;
        this.precioPorNoche = precioPorNoche;
        this.reservas = new ArrayList<>();
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getPrecioPorNoche() {
        return precioPorNoche;
    }

    public void setPrecioPorNoche(double precioPorNoche) {
        this.precioPorNoche = precioPorNoche;
    }

    public List<Reserva> getReservas() {
        return reservas;
    }

    public boolean esDisponible(Date fechaInicio, Date fechaFin) {
        for (Reserva reserva : reservas) {
            if (reserva.getFechaInicio().before(fechaFin) && reserva.getFechaFin().after(fechaInicio)) {
                return false;
            }
        }
        return true;
    }
}



