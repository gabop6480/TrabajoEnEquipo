package udla.trabajoGrupoHotel;

import udla.trabajoGrupoHotel.modelo.Hotel;
import udla.trabajoGrupoHotel.modelo.Habitacion;
import udla.trabajoGrupoHotel.modelo.Reserva;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Hotel hotel = new Hotel("Mamitas Puebla", "Avenida Principal Chuchurumin");

        // Agregar habitaciones al hotel
        hotel.agregarHabitacion(new Habitacion(101, "Simple", 50.0));
        hotel.agregarHabitacion(new Habitacion(102, "Doble", 80.0));
        hotel.agregarHabitacion(new Habitacion(103, "Suite", 150.0));

        while (true) {
            System.out.println("\n--- Sistema de Gestión de Reservas ---");
            System.out.println("Hotel: " + hotel.getNombre());
            System.out.println("Dirección: " + hotel.getDireccion());
            System.out.println("1. Consultar disponibilidad de habitaciones");
            System.out.println("2. Crear una nueva reserva");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1: // Consultar disponibilidad
                    consultarDisponibilidad(hotel, scanner);
                    break;

                case 2: // Crear una nueva reserva
                    crearReserva(hotel, scanner);
                    break;

                case 3: // Salir
                    System.out.println("¡Gracias por usar el sistema de gestión de reservas!");
                    scanner.close();
                    return;

                default:
                    System.out.println("Opción no válida. Por favor, intente de nuevo.");
            }
        }
    }

    private static void consultarDisponibilidad(Hotel hotel, Scanner scanner) {
        System.out.println("\n--- Consultar Disponibilidad ---");
        Date[] fechas = pedirFechas(scanner);

        List<Habitacion> disponibles = hotel.consultarDisponibilidad(fechas[0], fechas[1]);

        if (disponibles.isEmpty()) {
            System.out.println("Lo sentimos, no hay habitaciones disponibles para las fechas seleccionadas.");
        } else {
            System.out.println("Habitaciones disponibles:");
            for (Habitacion habitacion : disponibles) {
                System.out.println("Número: " + habitacion.getNumero() +
                        ", Tipo: " + habitacion.getTipo() +
                        ", Precio por noche: $" + habitacion.getPrecioPorNoche());
            }
        }
    }

    private static void crearReserva(Hotel hotel, Scanner scanner) {
        System.out.println("\n--- Crear Nueva Reserva ---");
        System.out.println("Primero, verificaremos la disponibilidad de habitaciones.");
        Date[] fechas = pedirFechas(scanner);

        List<Habitacion> disponibles = hotel.consultarDisponibilidad(fechas[0], fechas[1]);

        if (disponibles.isEmpty()) {
            System.out.println("Lo sentimos, no hay habitaciones disponibles para las fechas seleccionadas.");
            return;
        }

        System.out.println("Habitaciones disponibles:");
        for (Habitacion habitacion : disponibles) {
            System.out.println("Número: " + habitacion.getNumero() +
                    ", Tipo: " + habitacion.getTipo() +
                    ", Precio por noche: $" + habitacion.getPrecioPorNoche());
        }

        System.out.print("Ingrese el número de habitación que desea reservar: ");
        int numeroHabitacion = scanner.nextInt();

        Habitacion habitacionSeleccionada = null;
        for (Habitacion habitacion : disponibles) {
            if (habitacion.getNumero() == numeroHabitacion) {
                habitacionSeleccionada = habitacion;
                break;
            }
        }

        if (habitacionSeleccionada == null) {
            System.out.println("La habitación seleccionada no está disponible.");
            return;
        }

        System.out.print("Ingrese su nombre: ");
        scanner.nextLine(); // Consumir el salto de línea
        String cliente = scanner.nextLine();

        Reserva reserva = new Reserva(hotel.getHabitaciones().size() + 1, fechas[0], fechas[1], cliente, habitacionSeleccionada);

        if (hotel.realizarReserva(reserva)) {
            long diasEstancia = reserva.calcularDiasEstancia();
            double costoTotal = reserva.calcularCostoTotal();

            System.out.println("Reserva realizada exitosamente:");
            System.out.println("Cliente: " + reserva.getCliente());
            System.out.println("Habitación: " + habitacionSeleccionada.getNumero() + " (" + habitacionSeleccionada.getTipo() + ")");
            System.out.println("Fechas: " + fechas[0] + " a " + fechas[1]);
            System.out.println("Días de estancia: " + diasEstancia);
            System.out.println("Costo total: $" + costoTotal);
        } else {
            System.out.println("No se pudo realizar la reserva.");
        }
    }

    private static Date[] pedirFechas(Scanner scanner) {
        System.out.print("Ingrese la fecha de inicio (formato: yyyy-MM-dd): ");
        Date fechaInicio = java.sql.Date.valueOf(scanner.next());

        System.out.print("Ingrese la fecha de fin (formato: yyyy-MM-dd): ");
        Date fechaFin = java.sql.Date.valueOf(scanner.next());

        return new Date[]{fechaInicio, fechaFin};
    }
}



